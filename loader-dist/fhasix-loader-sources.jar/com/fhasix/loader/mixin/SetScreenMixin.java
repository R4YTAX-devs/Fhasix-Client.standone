package com.fhasix.loader.mixin;

import com.fhasix.loader.FhasixLoader;
import com.fhasix.loader.UpdateScreen;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Puts the Update screen in front of the very first title screen. */
@Mixin(class_310.class)
public abstract class SetScreenMixin {

    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true, require = 0)
    private class_437 fhasixloader$gate(class_437 screen) {
        if (screen instanceof class_442 && !FhasixLoader.gateDone) {
            FhasixLoader.gateDone = true;
            return new UpdateScreen(screen);
        }
        return screen;
    }
}
