package com.fhasix.loader;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_5481;

/** Full-screen update gate shown before the title screen. No cancel while an update is pending. */
public final class UpdateScreen extends class_437 {
    private final class_437 next;
    private final Updater up = FhasixLoader.UPDATER;
    private RedButton primary;
    private RedButton secondary;

    public UpdateScreen(class_437 next) {
        super(class_2561.method_43470("FHASIX Update"));
        this.next = next;
    }

    @Override
    protected void method_25426() {
        int w = 200, h = 20;
        int x = this.field_22789 / 2 - w / 2;
        int y = this.field_22790 / 2 + 24;
        primary = this.method_37063(new RedButton(x, y, w, h, class_2561.method_43470("Update"), b -> onPrimary()));
        secondary = this.method_37063(new RedButton(x, y + 26, w, h,
                class_2561.method_43470("Quit game"), b -> this.field_22787.method_1592()));
        refreshButtons();
    }

    private void onPrimary() {
        switch (up.state) {
            case NEEDS_UPDATE -> up.startApply();
            case ERROR -> up.startCheck();
            case DONE -> this.field_22787.method_1592();
            default -> { }
        }
    }

    private void refreshButtons() {
        if (primary == null) return;
        Updater.State s = up.state;
        switch (s) {
            case NEEDS_UPDATE -> setPrimary(true, up.firstInstall ? "Install" : "Update");
            case ERROR -> setPrimary(true, "Retry");
            case DONE -> setPrimary(true, "Close game");
            default -> setPrimary(false, "");
        }
        secondary.field_22764 = s == Updater.State.ERROR;
        secondary.field_22763 = secondary.field_22764;
    }

    private void setPrimary(boolean on, String label) {
        primary.field_22764 = on;
        primary.field_22763 = on;
        if (on) primary.method_25355(class_2561.method_43470(label));
    }

    @Override
    public void method_25393() {
        if (up.state == Updater.State.UP_TO_DATE) {
            this.field_22787.method_1507(next);
            return;
        }
        refreshButtons();
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xFF070708);
        int pw = Math.min(this.field_22789 - 20, 320);
        int x0 = this.field_22789 / 2 - pw / 2;
        int y0 = this.field_22790 / 2 - 78;
        int y1 = this.field_22790 / 2 + 84;
        context.method_25294(x0, y0, x0 + pw, y1, 0xFFB3262B);
        context.method_25294(x0 + 1, y0 + 1, x0 + pw - 1, y1 - 1, 0xFF101012);
        context.method_25294(x0 + 1, y0 + 1, x0 + pw - 1, y0 + 3, 0xFFE13B3E);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        int cx = this.field_22789 / 2;
        int pw = Math.min(this.field_22789 - 20, 320);

        center(context, "FHASIX CLIENT", cx, this.field_22790 / 2 - 62, 0xFFE13B3E);

        String line1;
        String line2 = "";
        int color2 = 0xFF9A9A9F;
        switch (up.state) {
            case CHECKING -> line1 = "Checking for updates...";
            case NEEDS_UPDATE -> {
                line1 = up.firstInstall ? "Install " + up.remoteVersion : "Update available: " + up.remoteVersion;
                line2 = up.firstInstall ? "FHASIX Client needs to be downloaded." : "An update is required to continue.";
            }
            case DOWNLOADING -> {
                line1 = "Downloading " + up.remoteVersion + "...  " + Math.round(up.progress * 100) + "%";
                line2 = "Please wait, do not close the game.";
            }
            case DONE -> {
                line1 = "Done!";
                line2 = "Restart the game to finish.";
            }
            case ERROR -> {
                line1 = "Something went wrong";
                line2 = up.message;
                color2 = 0xFFFF8A8A;
            }
            default -> line1 = "";
        }
        center(context, line1, cx, this.field_22790 / 2 - 44, 0xFFE6E8EB);

        if (!line2.isEmpty()) {
            List<class_5481> lines = this.field_22793.method_1728(class_2561.method_43470(line2), pw - 30);
            int y = this.field_22790 / 2 - 30;
            for (class_5481 l : lines) {
                context.method_51430(this.field_22793, l, cx - this.field_22793.method_30880(l) / 2, y, color2, true);
                y += 11;
            }
        }

        if (up.state == Updater.State.DOWNLOADING || up.state == Updater.State.DONE) {
            int bw = pw - 40;
            int bx = cx - bw / 2;
            int by = this.field_22790 / 2 + 6;
            context.method_25294(bx, by, bx + bw, by + 6, 0xFF2A1416);
            context.method_25294(bx, by, bx + Math.round(bw * up.progress), by + 6, 0xFFE13B3E);
        }
    }

    private void center(class_332 c, String s, int cx, int y, int color) {
        class_2561 t = class_2561.method_43470(s);
        c.method_51439(this.field_22793, t, cx - this.field_22793.method_27525(t) / 2, y, color, true);
    }

    @Override
    public boolean method_25422() {
        return false;
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
