package com.fhasix.loader;

import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4185;

/** Flat red/black button matching the FHASIX theme. */
public class RedButton extends class_4185 {

    public RedButton(int x, int y, int width, int height, net.minecraft.class_2561 message, class_4241 onPress) {
        super(x, y, width, height, message, onPress, field_40754);
    }

    @Override
    public void method_75752(class_332 context, int mouseX, int mouseY, float delta) {
        int x = this.method_46426(), y = this.method_46427(), w = this.method_25368(), h = this.method_25364();
        boolean hover = this.method_49606() && this.field_22763;

        int border = this.field_22763 ? 0xFFB3262B : 0xFF3A3A3E;
        int base = this.field_22763 ? (hover ? 0xFF8E1D21 : 0xFF1A0E0F) : 0xFF141416;
        context.method_25294(x, y, x + w, y + h, border);
        context.method_25294(x + 1, y + 1, x + w - 1, y + h - 1, base);

        class_327 tr = class_310.method_1551().field_1772;
        net.minecraft.class_2561 label = this.method_25369();
        int color = this.field_22763 ? 0xFFFFFFFF : 0xFF77777C;
        context.method_51439(tr, label, x + (w - tr.method_27525(label)) / 2, y + (h - tr.field_2000) / 2 + 1, color, true);
    }
}
